#pragma once

class $fileinputname$;
class $fileinputname$Manager
{
private:
	static $fileinputname$Manager* Inst;

public:
	static $fileinputname$Manager& GetInst()
	{
		return *Inst;
	}

	static void Destroy()
	{
		if (nullptr != Inst)
		{
			delete Inst;
			Inst = nullptr;
		}
	}

private:	// member Var
	std::map<std::string, $fileinputname$*> ResourcesMap;

public:
	$fileinputname$* Create(const std::string& _Name);
	$fileinputname$* Load(const std::string& _Path);
	$fileinputname$* Load(const std::string& _Name, const std::string& _Path);
	$fileinputname$* Find(const std::string& _Name);

private:
	$fileinputname$Manager();
	~$fileinputname$Manager();

protected:		// delete constructer
	$fileinputname$Manager(const $fileinputname$Manager& _other) = delete;
	$fileinputname$Manager($fileinputname$Manager&& _other) noexcept;

private:		//delete operator
	$fileinputname$Manager& operator=(const $fileinputname$Manager& _other) = delete;
	$fileinputname$Manager& operator=(const $fileinputname$Manager&& _other) = delete;

public:

};




