#include "PreCompile.h"
#include "$safeitemname$.h"

$safeitemname$::$safeitemname$()
{
}

$safeitemname$::~$safeitemname$()
{
}
