#pragma once

// �з� : 
// �뵵 : 
// ���� : 
class $safeitemname$
{
private:	// member Var

public:
	$safeitemname$();
	~$safeitemname$();

protected:		// delete constructer
	$safeitemname$(const $safeitemname$& _other) = delete;
	$safeitemname$($safeitemname$&& _other) noexcept = delete;

private:		//delete operator
	$safeitemname$& operator=(const $safeitemname$& _other) = delete;
	$safeitemname$& operator=(const $safeitemname$&& _other) = delete;

public:
};

